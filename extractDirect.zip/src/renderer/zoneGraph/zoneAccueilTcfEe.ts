// zoneAccueilTcfEe.ts
//
// Construit la page TCF · EE de l'accueil : zone à droite listant les
// cartes (une par dossier tcf_ee — voir donnee_tcf_ee.ts, backend) et,
// au centre, EXACTEMENT le même mode d'affichage que TCF · EO (voir
// zoneAccueilTcfEo.ts) : une entête, une navigation numérotée à gauche
// (une entrée par PARTIE, avec Préc./Suiv.), et pour la partie
// sélectionnée, une zone par tâche avec sa colonne "Extrait" (fixe, à
// gauche), son bouton de copie (▶) et sa colonne "Transformé" (éditable,
// à droite, enregistrée à la perte de focus).
//
// Seule différence avec l'EO : les libellés des blocs sont FIXES plutôt
// que génériques ("Sujet N"), pour refléter la structure réelle de
// l'épreuve EE :
//   - tache2 (2 éléments)  -> "Tâche 1", "Tâche 2"
//   - tache3 (3 éléments)  -> "Tâche 3 · Thème", "Tâche 3 · Document 1",
//                             "Tâche 3 · Document 2"
//
// Contrairement aux autres types, TCF EE ne passe PAS par
// conserveurDonne.ts : toutes les données viennent de
// donneeTcfEeApi.ts, qui ne parle qu'aux canaux 'tcf-ee:*' (câblés sur
// donnee_tcf_ee.ts côté backend — seule source de vérité pour l'EE du
// TCF).
import { construireCorpsPage, afficherMessageZone } from '../composer/corpsPage.js';
import { Selecteur } from '../generale/selecteur.js';
import { creerBoutonSupprimerCarte } from '../generale/carteSuppression.js';
import { creerMessage, typeErreur } from './gestionMessage.js';
import { creerBoutonExportZone, afficherBoutonExportZone } from './boutonExportZone.js';
import { estQuestionExportable } from './verificationExport.js';
import { construireSectionStats, calculerStatsExtraitTcfEeEo, calculerStatsTransformeTcfEeEo } from './statsElement.js';
import {
    CarteTcfEe,
    PartieEE,
    listerTcfEe,
    lireTcfEe,
    sauvegarderTransformeTcfEe,
    supprimerTcfEe,
} from './donneeTcfEeApi.js';

// Libellés fixes des blocs (voir en-tête du fichier).
const LIBELLES_TACHE2 = ['Tâche 1', 'Tâche 2'];
const LIBELLES_TACHE3 = ['Tâche 3 · Thème', 'Tâche 3 · Document 1', 'Tâche 3 · Document 2'];

/**
 * Construit le corps de la page TCF · EE : zone à droite (une carte
 * par dossier tcf_ee) + zone d'affichage (centre, navigation par
 * partie + zones Tâche 1/2/3).
 */
export const remplirZoneTcfEe = async (page: HTMLDivElement): Promise<void> => {
    const { zoneAffichage, listeCartes } = construireCorpsPage(
        page,
        'Aucune donnée EE extraite pour le moment.'
    );
    afficherMessageZone(zoneAffichage, 'Sélectionnez une carte pour afficher son contenu.');

    const selecteurCartes = new Selecteur<HTMLDivElement>(
        (carte) => carte.classList.add('nm-carte-elt-actif'),
        (carte) => carte.classList.remove('nm-carte-elt-actif')
    );

    listeCartes.setEmptyMessage('Chargement des données EE...');
    try {
        const cartes = await listerTcfEe();
        listeCartes.setEmptyMessage('Aucune donnée EE extraite pour le moment.');

        // ouvrirPremiereCarte retient le déclenchement (mêmes actions que
        // le clic) de la toute première carte affichée, pour l'ouvrir
        // automatiquement une fois la liste construite (voir plus bas) :
        // dès qu'il y a au moins une carte, une carte reste toujours
        // ouverte au centre plutôt que le message "Sélectionnez...".
        let ouvrirPremiereCarte: (() => void) | null = null;

        for (const infoCarte of cartes) {
            const resultat = await lireTcfEe(infoCarte.id);
            const extrait = resultat.success ? (resultat.extrait ?? []) : [];
            const transforme = resultat.success ? (resultat.transforme ?? extrait) : null;

            const ouvrirCarte = () => {
                selecteurCartes.selectUnique(carte);
                void afficherContenuTcfEe(zoneAffichage, infoCarte);
            };
            const carte = creerCarteTcfEe(infoCarte, extrait, transforme, ouvrirCarte, () =>
                void remplirZoneTcfEe(page)
            );
            listeCartes.addItem(carte);

            if (!ouvrirPremiereCarte) ouvrirPremiereCarte = ouvrirCarte;
        }

        // Ouvre par défaut la première carte, s'il y en a au moins une.
        ouvrirPremiereCarte?.();
    } catch {
        listeCartes.setEmptyMessage('Erreur lors du chargement des données EE.');
    }
};

// Pour retrouver, après une sauvegarde, la section "Transformé" d'une
// carte déjà construite, afin de rafraîchir ses stats sans tout
// reconstruire — même principe que cartesSuivies dans
// zoneAccueilTef.ts. Clé : l'id de la carte (infoCarte.id).
interface CarteTcfEeSuivie {
    zoneStats: HTMLDivElement;
    sectionTrans: HTMLDivElement;
}
const cartesTcfEeSuivies = new Map<string, CarteTcfEeSuivie>();

// Construit la carte représentant un dossier tcf_ee : entête
// (badge + titre) puis stats Extrait/Transformé — même gabarit que les
// cartes TEF/TCF · CO (voir creerCarteElement, zoneAccueilTef.ts).
const creerCarteTcfEe = (
    infoCarte: CarteTcfEe,
    extrait: PartieEE[],
    transforme: PartieEE[] | null,
    onClick: () => void,
    onSupprime: () => void
): HTMLDivElement => {
    const carte = document.createElement('div');
    carte.className = 'nm-carte-elt nm-carte-elt--ee';
    carte.addEventListener('click', onClick);

    const entete = document.createElement('div');
    entete.className = 'nm-carte-elt-entete';

    const badge = document.createElement('span');
    badge.className = 'nm-carte-elt-badge';
    badge.textContent = 'EE';

    const titre = document.createElement('span');
    titre.className = 'nm-carte-elt-titre';
    titre.textContent = infoCarte.nom;
    titre.title = infoCarte.nom;

    const boutonSuppr = creerBoutonSupprimerCarte(
        infoCarte.nom,
        () => supprimerTcfEe(infoCarte.id),
        onSupprime
    );

    entete.append(badge, titre, boutonSuppr);
    carte.appendChild(entete);

    const zoneStats = document.createElement('div');
    zoneStats.className = 'nm-carte-elt-stats';

    const sectionExtrait = construireSectionStats('Extrait', 'extrait', calculerStatsExtraitTcfEeEo(extrait));
    const sectionTrans = construireSectionStats('Transformé', 'trans', calculerStatsTransformeTcfEeEo(transforme));
    zoneStats.append(sectionExtrait, sectionTrans);
    carte.appendChild(zoneStats);

    cartesTcfEeSuivies.set(infoCarte.id, { zoneStats, sectionTrans });

    return carte;
};

// Rafraîchit la section "Transformé" d'une carte déjà construite, juste
// après une sauvegarde (voir enregistrer, plus bas) : les stats
// reflètent alors immédiatement l'état en mémoire (etatTransforme).
const rafraichirCarteTcfEeApresSauvegarde = (idCarte: string, parties: PartieEE[]): void => {
    const suivie = cartesTcfEeSuivies.get(idCarte);
    if (!suivie) return;
    const nouvelleSection = construireSectionStats('Transformé', 'trans', calculerStatsTransformeTcfEeEo(parties));
    suivie.zoneStats.replaceChild(nouvelleSection, suivie.sectionTrans);
    suivie.sectionTrans = nouvelleSection;
    cartesTcfEeSuivies.set(idCarte, suivie);
};

// Affiche, dans la zone d'affichage, le contenu d'une carte tcf_ee :
// navigation numérotée (une entrée par partie) + zones Tâche 1/2/3 de
// la partie sélectionnée.
const afficherContenuTcfEe = async (zoneAffichage: HTMLDivElement, infoCarte: CarteTcfEe): Promise<void> => {
    afficherMessageZone(zoneAffichage, 'Chargement...');

    const resultat = await lireTcfEe(infoCarte.id);
    if (!resultat.success) {
        afficherMessageZone(zoneAffichage, resultat.error ?? 'Impossible de charger cette donnée.');
        return;
    }

    const extrait = resultat.extrait ?? [];
    const transforme = resultat.transforme ?? extrait;
    if (extrait.length === 0) {
        afficherMessageZone(zoneAffichage, 'Aucune partie à afficher.');
        return;
    }

    // État transformé courant, une entrée par partie (même ordre que
    // l'extrait) — modifié en mémoire à chaque frappe, enregistré (le
    // tableau complet) à la perte de focus de n'importe quel champ.
    const etatTransforme: PartieEE[] = extrait.map((partie, index) => ({
        nomPartie: partie.nomPartie,
        tache2: transforme[index]?.tache2 ?? partie.tache2,
        tache3: transforme[index]?.tache3 ?? partie.tache3,
    }));

    const enregistrer = (): void => {
        rafraichirCarteTcfEeApresSauvegarde(infoCarte.id, etatTransforme);
        void sauvegarderTransformeTcfEe(infoCarte.id, etatTransforme).then((res) => {
            if (!res.success) creerMessage(typeErreur, infoCarte.nom, res.error ?? "Échec de l'enregistrement.");
        });
        rafraichirIndicateursExport();
    };

    // --- Construction de la zone (entête + navigation + contenu) ---
    zoneAffichage.innerHTML = '';

    const racine = document.createElement('div');
    racine.className = 'affichage-embed';

    const enteteEmbed = document.createElement('div');
    enteteEmbed.className = 'affichage-embed-entete';

    const enteteTitre = document.createElement('span');
    enteteTitre.className = 'affichage-embed-entete-titre';
    enteteTitre.textContent = `${infoCarte.nom} — EE`;
    enteteEmbed.appendChild(enteteTitre);

    // Indicateur d'exportabilité : reste vide tant que toutes les
    // parties ne sont pas prêtes à l'exportation, sinon affiche
    // combien il en reste à corriger (voir rafraichirIndicateursExport
    // plus bas, appelée à l'ouverture et à chaque modification, via
    // enregistrer()).
    const zoneExportStatut = document.createElement('span');
    zoneExportStatut.className = 'affichage-embed-export-statut';
    enteteEmbed.appendChild(zoneExportStatut);

    const boutonExport = creerBoutonExportZone('tcf-ee', () => infoCarte.id);
    enteteEmbed.appendChild(boutonExport);

    racine.appendChild(enteteEmbed);

    const layout = document.createElement('div');
    layout.className = 'affichage-layout';

    const nav = document.createElement('div');
    nav.className = 'affichage-nav';

    const zoneNavListe = document.createElement('div');
    zoneNavListe.className = 'affichage-nav-liste';
    nav.appendChild(zoneNavListe);

    const navigation = document.createElement('div');
    navigation.className = 'affichage-nav-navigation';

    const btnPrecedent = document.createElement('button');
    btnPrecedent.className = 'affichage-nav-fleche';
    btnPrecedent.textContent = '◀ Préc.';

    const indicateurPosition = document.createElement('div');
    indicateurPosition.className = 'affichage-nav-indicateur';

    const btnSuivant = document.createElement('button');
    btnSuivant.className = 'affichage-nav-fleche';
    btnSuivant.textContent = 'Suiv. ▶';

    navigation.append(btnPrecedent, indicateurPosition, btnSuivant);
    nav.appendChild(navigation);

    const zoneContenu = document.createElement('div');
    zoneContenu.className = 'affichage-contenu';

    layout.append(nav, zoneContenu);
    racine.appendChild(layout);
    zoneAffichage.appendChild(racine);

    let indexCourant = 0;
    let boutonsNav: HTMLButtonElement[] = [];

    // Recalcule, pour CHAQUE partie de la carte ouverte, son état
    // "prête à l'exportation" (voir estQuestionExportable dans
    // verificationExport.ts), puis met à jour le style distinctif du
    // bouton numéroté correspondant ainsi que le message d'entête
    // (rien ne s'affiche dès que tout est prêt).
    const rafraichirIndicateursExport = (): void => {
        let nombreNonPrets = 0;
        extrait.forEach((partieExtrait, index) => {
            const pret = estQuestionExportable('tcf-ee', partieExtrait, etatTransforme[index]);
            if (!pret) nombreNonPrets++;
            boutonsNav[index]?.classList.toggle('affichage-nav-btn--exportable', pret);
        });

        afficherBoutonExportZone(boutonExport, extrait.length > 0 && nombreNonPrets === 0);

        if (extrait.length === 0 || nombreNonPrets === 0) {
            zoneExportStatut.textContent = '';
            zoneExportStatut.classList.remove('affichage-embed-export-statut--visible');
        } else {
            zoneExportStatut.textContent = nombreNonPrets === 1
                ? '1 partie à corriger avant l’exportation'
                : `${nombreNonPrets} parties à corriger avant l’exportation`;
            zoneExportStatut.classList.add('affichage-embed-export-statut--visible');
        }
    };

    const selectionnerIndex = (index: number): void => {
        if (index < 0 || index >= extrait.length) return;
        indexCourant = index;

        boutonsNav.forEach((btn, i) => btn.classList.toggle('affichage-nav-btn--active', i === index));
        boutonsNav[index]?.scrollIntoView({ block: 'nearest' });

        const partieExtrait = extrait[index];
        const partieTrans = etatTransforme[index];

        zoneContenu.innerHTML = '';

        const entete = document.createElement('div');
        entete.className = 'affichage-contenu-entete';
        const titre = document.createElement('h3');
        titre.className = 'affichage-contenu-titre';
        titre.textContent = partieExtrait.nomPartie || `Partie ${index + 1}`;
        entete.appendChild(titre);
        zoneContenu.appendChild(entete);

        construireZonesTache(LIBELLES_TACHE2, partieExtrait.tache2 ?? [], partieTrans, 'tache2', enregistrer)
            .forEach((zone) => zoneContenu.appendChild(zone));
        construireZonesTache(LIBELLES_TACHE3, partieExtrait.tache3 ?? [], partieTrans, 'tache3', enregistrer)
            .forEach((zone) => zoneContenu.appendChild(zone));

        indicateurPosition.textContent = `${index + 1} / ${extrait.length}`;
        btnPrecedent.disabled = index === 0;
        btnSuivant.disabled = index === extrait.length - 1;
    };

    btnPrecedent.addEventListener('click', () => selectionnerIndex(indexCourant - 1));
    btnSuivant.addEventListener('click', () => selectionnerIndex(indexCourant + 1));

    zoneNavListe.innerHTML = '';
    boutonsNav = extrait.map((_, index) => {
        const btn = document.createElement('button');
        btn.className = 'affichage-nav-btn';
        btn.textContent = String(index + 1);
        btn.addEventListener('click', () => selectionnerIndex(index));
        zoneNavListe.appendChild(btn);
        return btn;
    });

    rafraichirIndicateursExport();
    selectionnerIndex(0);
};

// Construit un bloc (titre + colonne extrait + bouton de copie + colonne
// transformée) par élément du tableau `champ`, avec un libellé FIXE
// (voir LIBELLES_TACHE2/LIBELLES_TACHE3) plutôt que générique — si le
// tableau reçu est plus long que la liste de libellés prévue, les
// éléments en trop retombent sur un libellé générique de secours.
const construireZonesTache = (
    libelles: string[],
    paragraphesExtrait: string[],
    partieTrans: PartieEE,
    champ: 'tache2' | 'tache3',
    enregistrer: () => void
): HTMLDivElement[] => {
    const transExistant = partieTrans[champ] ?? [];
    const nb = Math.max(paragraphesExtrait.length, transExistant.length, libelles.length);

    const zones: HTMLDivElement[] = [];
    for (let i = 0; i < nb; i++) {
        const titreZone = libelles[i] ?? `${champ === 'tache2' ? 'Tâche 1/2' : 'Tâche 3'} · Sujet ${i + 1}`;
        zones.push(
            construireZoneSujet(titreZone, paragraphesExtrait[i] ?? '', partieTrans, champ, i, enregistrer)
        );
    }
    return zones;
};

const construireZoneSujet = (
    titreZone: string,
    extraitTexte: string,
    partieTrans: PartieEE,
    champ: 'tache2' | 'tache3',
    index: number,
    enregistrer: () => void
): HTMLDivElement => {
    const carte = document.createElement('div');
    carte.className = 'zed-zone';

    const titre = document.createElement('h4');
    titre.className = 'zed-zone-titre';
    titre.textContent = titreZone;
    carte.appendChild(titre);

    const corps = document.createElement('div');
    corps.className = 'zed-zone-corps';

    // Colonne extrait (fixe)
    const colExtrait = document.createElement('div');
    colExtrait.className = 'zed-col zed-col-extrait';
    const labelExtrait = document.createElement('div');
    labelExtrait.className = 'zed-col-label';
    labelExtrait.textContent = 'Extrait';
    colExtrait.appendChild(labelExtrait);

    const contenuExtrait = document.createElement('div');
    contenuExtrait.className = 'zed-extrait-contenu';
    if (!extraitTexte) {
        contenuExtrait.classList.add('zed-vide');
        contenuExtrait.textContent = 'Aucun contenu extrait.';
    } else {
        const bloc = document.createElement('div');
        bloc.className = 'zed-texte';
        bloc.textContent = extraitTexte;
        contenuExtrait.appendChild(bloc);
    }
    colExtrait.appendChild(contenuExtrait);

    // Bouton de copie (extrait -> transformé)
    const colBouton = document.createElement('div');
    colBouton.className = 'zed-col-bouton';
    const btnCopier = document.createElement('button');
    btnCopier.type = 'button';
    btnCopier.className = 'zed-copier-btn';
    btnCopier.textContent = '▶';
    btnCopier.disabled = !extraitTexte;
    btnCopier.title = !extraitTexte
        ? "Aucun extrait à copier ici."
        : "Copier l'extrait vers la partie transformée";
    colBouton.appendChild(btnCopier);

    // Colonne transformée (éditable) — une entrée précise du tableau
    // tache2/tache3 (partieTrans[champ][index]), pas le tableau entier.
    const colTrans = document.createElement('div');
    colTrans.className = 'zed-col zed-col-trans';
    const labelTrans = document.createElement('div');
    labelTrans.className = 'zed-col-label';
    const { element: indicateurStatut, definirStatut } = creerIndicateurStatutSimple();
    labelTrans.textContent = 'Transformé';
    labelTrans.appendChild(indicateurStatut);
    colTrans.appendChild(labelTrans);

    const zoneTransContenu = document.createElement('div');
    zoneTransContenu.className = 'zed-col-trans-contenu';

    const zoneTexte = document.createElement('textarea');
    zoneTexte.className = 'zed-textarea-trans';
    zoneTexte.value = (partieTrans[champ] ?? [])[index] ?? '';
    zoneTexte.placeholder = 'Saisissez le texte transformé...';
    zoneTexte.rows = 1;

    const ajusterHauteur = (): void => {
        zoneTexte.style.height = 'auto';
        zoneTexte.style.height = `${zoneTexte.scrollHeight}px`;
    };
    zoneTexte.addEventListener('input', ajusterHauteur);
    requestAnimationFrame(ajusterHauteur);

    // Écrit à l'index précis du tableau (en l'agrandissant si besoin),
    // sans toucher aux autres sujets de la même tâche.
    const ecrireDansPartieTrans = (texte: string): void => {
        const tableau = [...(partieTrans[champ] ?? [])];
        while (tableau.length <= index) tableau.push('');
        tableau[index] = texte;
        partieTrans[champ] = tableau;
    };

    zoneTexte.addEventListener('blur', () => {
        ecrireDansPartieTrans(zoneTexte.value);
        definirStatut('enregistrement');
        enregistrer();
        definirStatut('ok');
    });

    btnCopier.addEventListener('click', () => {
        zoneTexte.value = extraitTexte;
        ecrireDansPartieTrans(extraitTexte);
        ajusterHauteur();
        definirStatut('enregistrement');
        enregistrer();
        definirStatut('ok');
    });

    zoneTransContenu.appendChild(zoneTexte);
    colTrans.appendChild(zoneTransContenu);

    corps.append(colExtrait, colBouton, colTrans);
    carte.appendChild(corps);
    return carte;
};

// Petit indicateur textuel discret ("Enregistré ✓" / "Échec"), même
// comportement que creerIndicateurStatut dans zoneAff.ts.
const creerIndicateurStatutSimple = (): {
    element: HTMLSpanElement;
    definirStatut: (statut: 'enregistrement' | 'ok' | 'erreur' | null) => void;
} => {
    const element = document.createElement('span');
    element.className = 'zed-statut-save';
    let minuteur: ReturnType<typeof setTimeout> | null = null;

    const definirStatut = (statut: 'enregistrement' | 'ok' | 'erreur' | null): void => {
        if (minuteur) { clearTimeout(minuteur); minuteur = null; }
        element.className = 'zed-statut-save';
        if (!statut) { element.textContent = ''; return; }
        element.classList.add(`zed-statut-save--${statut}`);
        element.textContent = statut === 'enregistrement'
            ? 'Enregistrement...'
            : statut === 'ok'
                ? 'Enregistré ✓'
                : "Échec de l'enregistrement";
        if (statut === 'ok') {
            minuteur = setTimeout(() => {
                element.className = 'zed-statut-save';
                element.textContent = '';
            }, 2200);
        }
    };

    return { element, definirStatut };
};