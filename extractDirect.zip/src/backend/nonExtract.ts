import { creer_dossier, genereId, dossierConserveur, viderDossier, getRef, chargeRef, enregistreRef } from './gardienRef.js';
import path from 'path';
import fs from 'fs';
import { dialog } from "electron";
import AdmZip from "adm-zip";
import { enregistrerExtrait, cheminDossierSerie } from './conserveurDonne.js';
import { getCheminEnsDossierTef, supprimerRef as supprimerRefTef } from './gestion_ref_tef.js';

interface DictIntegrateur {
    [key: string]: (arg: any) => Promise<string>
}

const recupCheminZip = async () => {
    const result = await dialog.showOpenDialog({
        properties: ["openFile", "multiSelections"],
        filters: [{ name: "Archives", extensions: ["zip"] }]
    });
    return result.filePaths;
}

//nous creons un om de dossier qui vas cntenir les dossier qui seront utiliser puis supprimer
const dossierTampon = path.join(dossierConserveur, "dossier_tampon");
const fichierRefZip = path.join(dossierTampon, "ref.json");

//ici si le tampon existe on le vide et s'il n'existe pas on le cree
const initTampon = () => {
    if (!creer_dossier(dossierTampon)) {
        viderDossier(dossierTampon);
    }
}

export const dezipperFichier = (cheminZip: string): boolean => {
    initTampon();
    try {
        const zip = new AdmZip(cheminZip);
        zip.extractAllTo(dossierTampon, true);
        return true;
    } catch (error) {
        return false;
    }
};

// Réduit un texte à une longueur d'affichage raisonnable (nom de série
// affichable), sans jamais planter sur une valeur manquante.
const tronquerTexte = (texte: string | undefined | null, max: number): string => {
    const propre = (texte ?? '').replace(/\s+/g, ' ').trim();
    if (propre === '') return 'sujet';
    return propre.length <= max ? propre : `${propre.slice(0, max).trim()}…`;
};

//ici nous voulon genere un identifiant pa rapport a une chine de caracter sortie de ses données 
//le but est sortir une d qui nous pemettra de d'intgrer les elemnt intergrer dans le mme syteme de reference que les valeurs extraits tout evitant de mettre des chose qui existe deja
const fabId = (nomType: string, valeurRef: string) => {
    const clesDataId = `intergrer_${nomType}_id`;
    const dataId = getRef(clesDataId);
    let idDonnee = dataId[valeurRef];
    if (!idDonnee) {
        const clesCompId = `intergrer_compteur_${nomType}`;
        idDonnee = `intergrer_${nomType}_${genereId(clesCompId)}`;
        dataId[valeurRef] = idDonnee;
    }
    return idDonnee;
}

// getCheminEnsDossierTef (ré-utilisé ici volontairement, comme pour les
// liens extraits) crée/rafraîchit d'un coup les références des 4 types
// TEF (ce/co/ee/eo) pour un même id. Comme une intégration directe ne
// concerne qu'UN seul type à la fois, on retire ensuite les 3 références
// fabriquées en trop pour ce même id (sinon des cartes fantômes,
// pointant vers des dossiers jamais créés, apparaîtraient dans les
// listes des 3 autres types et planteraient à l'ouverture).
const nettoyerAutresTypes = (typeGarde: 'ce' | 'co' | 'ee' | 'eo', id: string) => {
    (['ce', 'co', 'ee', 'eo'] as const).forEach((type) => {
        if (type !== typeGarde) supprimerRefTef(type, id);
    });
};

// --- TEF-EE -------------------------------------------------------------
// ref.conserveur = nom du fichier JSON (dans le dossier tampon) contenant
// un tableau d'objets { sectionA, sectionB } (deux chaînes de texte).
const integrerTefEe = async (nomFichier: string): Promise<string> => {
    if (typeof nomFichier !== 'string' || nomFichier.trim() === '') {
        return "TEF-EE : conserveur invalide (nom de fichier attendu)";
    }

    const cheminFichier = path.join(dossierTampon, nomFichier);
    if (!fs.existsSync(cheminFichier)) {
        return `TEF-EE : fichier de données introuvable (${nomFichier})`;
    }

    let tableau: any[];
    try {
        const brut = fs.readFileSync(cheminFichier, 'utf-8');
        const parse = JSON.parse(brut);
        tableau = Array.isArray(parse) ? parse : [parse];
    } catch (err: any) {
        return `TEF-EE : fichier de données invalide (${nomFichier}) : ${err?.message ?? err}`;
    }

    let nbIntegres = 0;
    for (const item of tableau) {
        const sectionA = typeof item?.sectionA === 'string' ? item.sectionA : '';
        const sectionB = typeof item?.sectionB === 'string' ? item.sectionB : '';

        // id fabriqué à partir du collage sectionA + sectionB : un même
        // sujet réintégré retombe sur le même id (et donc le même dossier).
        const valeurRef = `${sectionA}|||${sectionB}`;
        const id = fabId('tef-ee', valeurRef);
        const nomAffichable = `EE ${tronquerTexte(sectionA, 50)}`;

        const items = [
            { epreuve: 'EE', numero: 1, section: 'Tâche A', consigne: sectionA },
            { epreuve: 'EE', numero: 2, section: 'Tâche B', consigne: sectionB },
        ];

        await enregistrerExtrait('ee', id, items, nomAffichable);
        nettoyerAutresTypes('ee', id);
        nbIntegres++;
    }

    return `TEF-EE : ${nbIntegres} sujet(s) intégré(s)`;
};

// --- TEF-EO -------------------------------------------------------------
// ref.conserveur = tableau de noms de dossier (dans le dossier tampon).
// Chaque dossier contient un donnee.json :
//   { sectionA: { enonce, urlPath, explication }, sectionB: { ... } }
// et les images référencées par urlPath, déjà présentes puisque tout le
// zip a été dézippé dans le dossier tampon en une seule fois.
const integrerTefEo = async (tabDossier: string[]): Promise<string> => {
    if (!Array.isArray(tabDossier)) {
        return "TEF-EO : conserveur invalide (tableau de dossiers attendu)";
    }

    let nbIntegres = 0;
    for (const nomDossier of tabDossier) {
        if (typeof nomDossier !== 'string' || nomDossier.trim() === '') continue;

        const dossierSource = path.join(dossierTampon, nomDossier);
        const cheminDonnee = path.join(dossierSource, 'donnee.json');
        if (!fs.existsSync(cheminDonnee)) continue;

        let donnee: any;
        try {
            donnee = JSON.parse(fs.readFileSync(cheminDonnee, 'utf-8'));
        } catch {
            continue;
        }

        const sectionA = donnee?.sectionA ?? {};
        const sectionB = donnee?.sectionB ?? {};

        const valeurRef = `${sectionA.enonce ?? ''}|||${sectionB.enonce ?? ''}`;
        const id = fabId('tef-eo', valeurRef);
        const nomAffichable = `EO ${tronquerTexte(sectionA.enonce, 50)}`;

        // Dossier cible (même mécanisme de référencement id -> dossier que
        // pour les liens extraits) : récupéré AVANT de copier les images,
        // pour que les chemins écrits dans eo.json pointent déjà vers des
        // fichiers existants au moment où enregistrerExtrait génère le
        // transformé (à la création).
        const dossierEo = getCheminEnsDossierTef(id, nomAffichable).eo;
        const serieDir = cheminDossierSerie(dossierEo);
        fs.mkdirSync(path.join(serieDir, 'img'), { recursive: true });

        const copierImage = (section: any): string => {
            const urlPath = typeof section?.urlPath === 'string' ? section.urlPath : '';
            if (urlPath === '') return '';
            const relatif = urlPath.replace(/\\/g, '/');
            const cheminSource = path.join(dossierSource, relatif);
            if (!fs.existsSync(cheminSource)) return '';
            const nomFichierImg = path.basename(relatif);
            fs.copyFileSync(cheminSource, path.join(serieDir, 'img', nomFichierImg));
            return `img/${nomFichierImg}`;
        };

        const items = (['A', 'B'] as const).map((lettre, index) => {
            const section = lettre === 'A' ? sectionA : sectionB;
            const imagePath = copierImage(section);
            return {
                epreuve: 'EO',
                numero: index + 1,
                section: `Tâche ${lettre}`,
                consigne: typeof section?.enonce === 'string' ? section.enonce : '',
                images: imagePath ? path.basename(imagePath) : '',
                imagesUrls: '',
                imagePath,
                explication: typeof section?.explication === 'string' ? section.explication : '',
            };
        });

        await enregistrerExtrait('eo', id, items, nomAffichable);
        nettoyerAutresTypes('eo', id);
        nbIntegres++;
    }

    return `TEF-EO : ${nbIntegres} sujet(s) intégré(s)`;
};

const dataIntegrateur: DictIntegrateur = {
    ["tef-eo"]: integrerTefEo,
    ["tef-ee"]: integrerTefEe,
};

export const integrerSujet = async () => {
    chargeRef();
    const cheminZips = await recupCheminZip();
    let message = "";

    // Boucle séquentielle (pas de forEach) : initTampon()/dezipperFichier
    // VIDE le dossier tampon à chaque zip, donc chaque zip doit être
    // entièrement traité (lecture des fichiers, copie des images) avant
    // de passer au suivant.
    for (const chemin of cheminZips) {
        if (!dezipperFichier(chemin)) {
            message += ` . ${chemin} : échec de la décompression`;
            continue;
        }

        if (!fs.existsSync(fichierRefZip)) {
            message += ` . ${chemin} non reconnu`;
            continue;
        }

        try {
            const strRef = fs.readFileSync(fichierRefZip, "utf-8");
            const ref = JSON.parse(strRef);
            const integrateur = dataIntegrateur[ref.type];
            if (!integrateur) {
                message += ` . ${chemin} : type "${ref.type}" non pris en charge`;
                continue;
            }
            message += ` . ${await integrateur(ref.conserveur)}`;
        } catch (err: any) {
            message += ` . ${chemin} : ${err?.message ?? err}`;
        }
    }

    enregistreRef();
    return message.trim() === '' ? "aucun fichier traité" : message.trim();
}